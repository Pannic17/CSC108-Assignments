# pylint: disable=missing-docstring

TEST = map(str, (1, 2, 3)) # [bad-builtin]
TEST1 = filter(str, (1, 2, 3)) # [bad-builtin]
